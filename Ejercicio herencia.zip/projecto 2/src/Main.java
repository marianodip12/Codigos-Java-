
class Persona {

    int edad;
    String nombre;
    String telefono;


    public Persona(int edad, String nombre, String telefono) {
        this.edad = edad;
        this.nombre = nombre;
        this.telefono = telefono;
    }
}


class Cliente extends Persona {
    double credito;

    public Cliente(int edad, String nombre, String telefono, double credito) {
        super(edad, nombre, telefono);
        this.credito = credito;
    }
}


class Trabajador extends Persona {

    double salario;


    public Trabajador(int edad, String nombre, String telefono, double salario) {

        super(edad, nombre, telefono);
        this.salario = salario;
    }
}


public class Main {
    public static void main(String[] args) {

        Cliente cliente = new Cliente(30, "Juan", "555-1234", 1000.0);

        System.out.println("Edad: " + cliente.edad);
        System.out.println("Nombre: " + cliente.nombre);
        System.out.println("Teléfono: " + cliente.telefono);
        System.out.println("Crédito: " + cliente.credito);


        Trabajador trabajador = new Trabajador(40, "Ana", "555-9876", 2000.0);

        System.out.println("Edad: " + trabajador.edad);
        System.out.println("Nombre: " + trabajador.nombre);
        System.out.println("Teléfono: " + trabajador.telefono);
        System.out.println("Salario: " + trabajador.salario);
    }
}
