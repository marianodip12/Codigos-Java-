public class Main {
    public static void main(String[] args) {
        int num=-3;
        if (num<0){
            System.out.println("es negativo");

        }else if(num>0){
            System.out.println("es positivo");

        }
        int numeroWhile = 0;

        while (numeroWhile < 3) {
            numeroWhile++;
            System.out.println(numeroWhile);
        }

        System.out.println("ejercicio do while");
        int numeroDoWhile = 0;

        do {
            numeroDoWhile++;
            System.out.println(numeroDoWhile);
        } while (numeroDoWhile < 3);

        System.out.println("ejercicio for ");
        int numeroFor = 0;

        for (numeroFor = 0; numeroFor <= 3; numeroFor++) {
            System.out.println(numeroFor);
        }


        var estacion="otoño";
        switch (estacion){
            case "invierno":
                System.out.println(estacion);
                break;
            case "vernano":
                System.out.println(estacion);
                break;
            case "otoño":
                System.out.println(estacion);
                break;
            case "primavera":
                System.out.println(estacion);
                break;
            default:
                System.out.println("no es ninguna estacion ");

        }
    }
}





